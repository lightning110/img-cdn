package com.coderpage.app.gradle.plugin

class Version {
    String token
    String appName
    String apkPath
    String changeLog
    String channelName
    boolean  isRelease
}