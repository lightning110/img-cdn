package com.coderpage.app.gradle.plugin

/**
 * @author lc. 2017-09-26 23:04
 * @since 0.5.0 */
class UploaderExtension {
    String token
    String apiServer
    String appName
    String changeLog
    boolean isRelease
}
