package com.coderpage.mine.app.tally.module.chart;

/**
 * @author lc. 2018-10-20 21:01
 * @since 0.6.0
 */


public class TallyChartViewModelTest {

}
