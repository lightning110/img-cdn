package com.coderpage.mine.app.tally.common;

/**
 * @author lc. 2019-04-14 14:17
 * @since 0.6.0
 *
 * 记录类型
 */

public enum RecordType {

    // 支出
    EXPENSE,
    // 收入
    INCOME
}
