package com.coderpage.mine.app.tally.module.home;

import android.view.View;

import com.coderpage.mine.app.tally.module.home.model.HomeDisplayData;

/**
 * @author lc. 2018-09-24 13:41
 * @since 0.6.0
 */

public class ViewHolderBottom extends BaseViewHolder {

    ViewHolderBottom(View view) {
        super(view);
    }

    @Override
    void bindData(HomeDisplayData data) {

    }
}
