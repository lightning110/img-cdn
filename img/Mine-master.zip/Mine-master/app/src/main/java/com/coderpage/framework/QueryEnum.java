package com.coderpage.framework;

/**
 * @author abner-l. 2017-04-08
 */

public interface QueryEnum {
    int getId();

    String[] getProjection();
}
