package com.coderpage.framework;

/**
 * @author abner-l. 2017-04-09
 */

public interface UserActionEnum {
    int getId();
}
