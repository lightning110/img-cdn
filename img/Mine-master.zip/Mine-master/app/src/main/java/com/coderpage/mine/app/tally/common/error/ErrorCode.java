package com.coderpage.mine.app.tally.common.error;

/**
 * @author abner-l. 2017-06-18
 */

public class ErrorCode extends com.coderpage.base.error.ErrorCode {

}
