package com.coderpage.base.common;

/**
 * @author abner-l. 2017-04-15
 */

public interface SimpleCallback<T> {
    void success(T t);
}
