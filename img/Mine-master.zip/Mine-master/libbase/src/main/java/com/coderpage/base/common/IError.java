package com.coderpage.base.common;

/**
 * @author abner-l. 2017-05-07
 */

public interface IError {

    int code();

    String msg();
}
